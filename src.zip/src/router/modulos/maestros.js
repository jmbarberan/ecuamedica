import { UserRole } from "@/utils/auth.roles";
//import { traducir } from "@/utils/traducir.js";

export default function maestrosRutas() {
  return [
    
  ];
}