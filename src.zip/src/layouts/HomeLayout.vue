<template>
  <div class="homepage">
    <slot></slot>
  </div>
</template>
<script>
export default {};
</script>
