export const UserRole = {
  Admin: 0,
  Ventas: 1,
  Bodega: 2,
  Cajero: 3,
  Medico: 4,
  Enfermeria: 5
};
